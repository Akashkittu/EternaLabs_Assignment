module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/app/api/tokens/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
const baseTokens = [
    // New pairs
    {
        id: 'sol-usdc',
        symbol: 'SOL',
        name: 'Solana',
        category: 'new_pairs',
        price: 180.23,
        priceChange24h: 0.042,
        volume24h: 1_203_456.78,
        marketCap: 8_000_000_000,
        liquidity: 0.92,
        lastUpdated: Date.now()
    },
    {
        id: 'pepe-usdc',
        symbol: 'PEPE',
        name: 'Pepe',
        category: 'new_pairs',
        price: 0.00000123,
        priceChange24h: -0.15,
        volume24h: 560_000.0,
        marketCap: 300_000_000,
        liquidity: 0.7,
        lastUpdated: Date.now()
    },
    // Final stretch
    {
        id: 'eth-usdc',
        symbol: 'ETH',
        name: 'Ethereum',
        category: 'final_stretch',
        price: 3400.12,
        priceChange24h: -0.013,
        volume24h: 9_345_678.9,
        marketCap: 43_000_000_000,
        liquidity: 0.97,
        lastUpdated: Date.now()
    },
    {
        id: 'wif-usdc',
        symbol: 'WIF',
        name: 'Dogwifhat',
        category: 'final_stretch',
        price: 4.21,
        priceChange24h: 0.23,
        volume24h: 3_100_000.0,
        marketCap: 1_200_000_000,
        liquidity: 0.88,
        lastUpdated: Date.now()
    },
    // Migrated
    {
        id: 'uni-eth',
        symbol: 'UNI',
        name: 'Uniswap',
        category: 'migrated',
        price: 9.4,
        priceChange24h: 0.03,
        volume24h: 1_040_000.0,
        marketCap: 5_000_000_000,
        liquidity: 0.9,
        lastUpdated: Date.now()
    },
    {
        id: 'link-eth',
        symbol: 'LINK',
        name: 'Chainlink',
        category: 'migrated',
        price: 18.5,
        priceChange24h: 0.015,
        volume24h: 2_040_000.0,
        marketCap: 6_000_000_000,
        liquidity: 0.93,
        lastUpdated: Date.now()
    }
];
async function GET(req) {
    const { searchParams } = new URL(req.url);
    const categoryParam = searchParams.get('category') ?? 'new_pairs';
    const data = baseTokens.filter((t)=>t.category === categoryParam);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(data);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__3f5accc7._.js.map