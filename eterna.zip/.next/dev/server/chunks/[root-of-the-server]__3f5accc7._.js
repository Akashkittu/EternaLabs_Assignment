module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/app/api/tokens/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
const now = Date.now();
const baseTokens = [
    // ----------------- NEW PAIRS (16) -----------------
    {
        id: 'sol-usdc',
        symbol: 'SOL',
        name: 'Solana',
        category: 'new_pairs',
        price: 197.0527,
        priceChange24h: 0.042,
        volume24h: 1_171_200,
        marketCap: 8_000_000_000,
        liquidity: 0.92,
        lastUpdated: now
    },
    {
        id: 'pepe-usdc',
        symbol: 'PEPE',
        name: 'Pepe',
        category: 'new_pairs',
        price: 0.00000123,
        priceChange24h: -0.15,
        volume24h: 691_800,
        marketCap: 300_000_000,
        liquidity: 0.7,
        lastUpdated: now
    },
    {
        id: 'bonk-usdc',
        symbol: 'BONK',
        name: 'Bonk',
        category: 'new_pairs',
        price: 0.0000213,
        priceChange24h: 0.18,
        volume24h: 980_000,
        marketCap: 450_000_000,
        liquidity: 0.81,
        lastUpdated: now
    },
    {
        id: 'jup-usdc',
        symbol: 'JUP',
        name: 'Jupiter',
        category: 'new_pairs',
        price: 1.238,
        priceChange24h: -0.034,
        volume24h: 1_430_000,
        marketCap: 1_200_000_000,
        liquidity: 0.9,
        lastUpdated: now
    },
    {
        id: 'ray-usdc',
        symbol: 'RAY',
        name: 'Raydium',
        category: 'new_pairs',
        price: 2.54,
        priceChange24h: 0.062,
        volume24h: 420_000,
        marketCap: 320_000_000,
        liquidity: 0.86,
        lastUpdated: now
    },
    {
        id: 'ordi-usdt',
        symbol: 'ORDI',
        name: 'Ordinals',
        category: 'new_pairs',
        price: 42.18,
        priceChange24h: 0.095,
        volume24h: 870_500,
        marketCap: 950_000_000,
        liquidity: 0.88,
        lastUpdated: now
    },
    {
        id: 'doge-usdt',
        symbol: 'DOGE',
        name: 'Dogecoin',
        category: 'new_pairs',
        price: 0.1823,
        priceChange24h: -0.021,
        volume24h: 2_013_400,
        marketCap: 24_000_000_000,
        liquidity: 0.96,
        lastUpdated: now
    },
    {
        id: 'shib-usdt',
        symbol: 'SHIB',
        name: 'Shiba Inu',
        category: 'new_pairs',
        price: 0.0000294,
        priceChange24h: 0.057,
        volume24h: 1_745_000,
        marketCap: 15_500_000_000,
        liquidity: 0.9,
        lastUpdated: now
    },
    {
        id: 'floki-usdt',
        symbol: 'FLOKI',
        name: 'Floki',
        category: 'new_pairs',
        price: 0.000215,
        priceChange24h: 0.133,
        volume24h: 540_000,
        marketCap: 280_000_000,
        liquidity: 0.78,
        lastUpdated: now
    },
    {
        id: 'meme-usdt',
        symbol: 'MEME',
        name: 'Memecoin',
        category: 'new_pairs',
        price: 0.032,
        priceChange24h: -0.074,
        volume24h: 360_000,
        marketCap: 190_000_000,
        liquidity: 0.8,
        lastUpdated: now
    },
    {
        id: 'pyth-usdc',
        symbol: 'PYTH',
        name: 'Pyth Network',
        category: 'new_pairs',
        price: 0.52,
        priceChange24h: 0.061,
        volume24h: 410_000,
        marketCap: 500_000_000,
        liquidity: 0.86,
        lastUpdated: now
    },
    {
        id: 'jito-usdc',
        symbol: 'JITO',
        name: 'Jito',
        category: 'new_pairs',
        price: 3.42,
        priceChange24h: 0.094,
        volume24h: 280_000,
        marketCap: 720_000_000,
        liquidity: 0.9,
        lastUpdated: now
    },
    {
        id: 'tensor-usdc',
        symbol: 'TNSR',
        name: 'Tensor',
        category: 'new_pairs',
        price: 1.06,
        priceChange24h: -0.038,
        volume24h: 190_000,
        marketCap: 310_000_000,
        liquidity: 0.83,
        lastUpdated: now
    },
    {
        id: 'worm-usdc',
        symbol: 'W',
        name: 'Wormhole',
        category: 'new_pairs',
        price: 0.84,
        priceChange24h: 0.049,
        volume24h: 270_000,
        marketCap: 1_000_000_000,
        liquidity: 0.88,
        lastUpdated: now
    },
    {
        id: 'troll-usdc',
        symbol: 'TROLL',
        name: 'Troll',
        category: 'new_pairs',
        price: 0.00000098,
        priceChange24h: -0.19,
        volume24h: 220_000,
        marketCap: 120_000_000,
        liquidity: 0.72,
        lastUpdated: now
    },
    {
        id: 'wld-usdc',
        symbol: 'WLD',
        name: 'Worldcoin',
        category: 'new_pairs',
        price: 2.76,
        priceChange24h: 0.057,
        volume24h: 510_000,
        marketCap: 410_000_000,
        liquidity: 0.85,
        lastUpdated: now
    },
    // ----------------- FINAL STRETCH (16) -----------------
    {
        id: 'eth-usdc',
        symbol: 'ETH',
        name: 'Ethereum',
        category: 'final_stretch',
        price: 3400.12,
        priceChange24h: -0.013,
        volume24h: 9_345_678.9,
        marketCap: 430_000_000_000,
        liquidity: 0.97,
        lastUpdated: now
    },
    {
        id: 'wif-usdc',
        symbol: 'WIF',
        name: 'Dogwifhat',
        category: 'final_stretch',
        price: 4.21,
        priceChange24h: 0.23,
        volume24h: 3_100_000,
        marketCap: 1_200_000_000,
        liquidity: 0.88,
        lastUpdated: now
    },
    {
        id: 'bnb-usdt',
        symbol: 'BNB',
        name: 'BNB',
        category: 'final_stretch',
        price: 615.42,
        priceChange24h: 0.027,
        volume24h: 2_540_000,
        marketCap: 95_000_000_000,
        liquidity: 0.95,
        lastUpdated: now
    },
    {
        id: 'avax-usdt',
        symbol: 'AVAX',
        name: 'Avalanche',
        category: 'final_stretch',
        price: 48.32,
        priceChange24h: -0.041,
        volume24h: 1_120_000,
        marketCap: 18_000_000_000,
        liquidity: 0.91,
        lastUpdated: now
    },
    {
        id: 'op-usdt',
        symbol: 'OP',
        name: 'Optimism',
        category: 'final_stretch',
        price: 3.14,
        priceChange24h: 0.082,
        volume24h: 620_000,
        marketCap: 4_800_000_000,
        liquidity: 0.87,
        lastUpdated: now
    },
    {
        id: 'arb-usdt',
        symbol: 'ARB',
        name: 'Arbitrum',
        category: 'final_stretch',
        price: 2.18,
        priceChange24h: 0.051,
        volume24h: 730_000,
        marketCap: 5_100_000_000,
        liquidity: 0.89,
        lastUpdated: now
    },
    {
        id: 'sei-usdt',
        symbol: 'SEI',
        name: 'Sei',
        category: 'final_stretch',
        price: 0.94,
        priceChange24h: -0.028,
        volume24h: 390_000,
        marketCap: 2_000_000_000,
        liquidity: 0.84,
        lastUpdated: now
    },
    {
        id: 'ena-usdt',
        symbol: 'ENA',
        name: 'Ethena',
        category: 'final_stretch',
        price: 0.87,
        priceChange24h: 0.066,
        volume24h: 410_000,
        marketCap: 1_450_000_000,
        liquidity: 0.86,
        lastUpdated: now
    },
    {
        id: 'ltc-usdt',
        symbol: 'LTC',
        name: 'Litecoin',
        category: 'final_stretch',
        price: 89.4,
        priceChange24h: 0.014,
        volume24h: 680_000,
        marketCap: 6_600_000_000,
        liquidity: 0.92,
        lastUpdated: now
    },
    {
        id: 'xrp-usdt',
        symbol: 'XRP',
        name: 'XRP',
        category: 'final_stretch',
        price: 0.68,
        priceChange24h: -0.021,
        volume24h: 3_100_000,
        marketCap: 37_000_000_000,
        liquidity: 0.96,
        lastUpdated: now
    },
    {
        id: 'ada-usdt',
        symbol: 'ADA',
        name: 'Cardano',
        category: 'final_stretch',
        price: 0.49,
        priceChange24h: 0.033,
        volume24h: 1_450_000,
        marketCap: 17_000_000_000,
        liquidity: 0.93,
        lastUpdated: now
    },
    {
        id: 'inj-usdt',
        symbol: 'INJ',
        name: 'Injective',
        category: 'final_stretch',
        price: 26.8,
        priceChange24h: 0.071,
        volume24h: 540_000,
        marketCap: 2_500_000_000,
        liquidity: 0.9,
        lastUpdated: now
    },
    {
        id: 'near-usdt',
        symbol: 'NEAR',
        name: 'NEAR Protocol',
        category: 'final_stretch',
        price: 7.24,
        priceChange24h: -0.036,
        volume24h: 720_000,
        marketCap: 8_000_000_000,
        liquidity: 0.9,
        lastUpdated: now
    },
    {
        id: 'sui-usdt',
        symbol: 'SUI',
        name: 'Sui',
        category: 'final_stretch',
        price: 1.43,
        priceChange24h: 0.058,
        volume24h: 330_000,
        marketCap: 1_700_000_000,
        liquidity: 0.88,
        lastUpdated: now
    },
    {
        id: 'apt-usdt',
        symbol: 'APT',
        name: 'Aptos',
        category: 'final_stretch',
        price: 9.85,
        priceChange24h: 0.044,
        volume24h: 510_000,
        marketCap: 3_800_000_000,
        liquidity: 0.89,
        lastUpdated: now
    },
    {
        id: 'strk-usdt',
        symbol: 'STRK',
        name: 'Starknet',
        category: 'final_stretch',
        price: 1.92,
        priceChange24h: -0.017,
        volume24h: 290_000,
        marketCap: 2_200_000_000,
        liquidity: 0.87,
        lastUpdated: now
    },
    // ----------------- MIGRATED (16) -----------------
    {
        id: 'uni-eth',
        symbol: 'UNI',
        name: 'Uniswap',
        category: 'migrated',
        price: 9.4,
        priceChange24h: 0.03,
        volume24h: 1_040_000,
        marketCap: 5_000_000_000,
        liquidity: 0.9,
        lastUpdated: now
    },
    {
        id: 'link-eth',
        symbol: 'LINK',
        name: 'Chainlink',
        category: 'migrated',
        price: 18.5,
        priceChange24h: 0.015,
        volume24h: 2_040_000,
        marketCap: 6_000_000_000,
        liquidity: 0.93,
        lastUpdated: now
    },
    {
        id: 'aave-eth',
        symbol: 'AAVE',
        name: 'Aave',
        category: 'migrated',
        price: 112.3,
        priceChange24h: -0.022,
        volume24h: 380_000,
        marketCap: 1_600_000_000,
        liquidity: 0.9,
        lastUpdated: now
    },
    {
        id: 'sushi-eth',
        symbol: 'SUSHI',
        name: 'SushiSwap',
        category: 'migrated',
        price: 1.82,
        priceChange24h: 0.071,
        volume24h: 210_000,
        marketCap: 420_000_000,
        liquidity: 0.85,
        lastUpdated: now
    },
    {
        id: 'crv-eth',
        symbol: 'CRV',
        name: 'Curve',
        category: 'migrated',
        price: 0.84,
        priceChange24h: -0.039,
        volume24h: 190_000,
        marketCap: 350_000_000,
        liquidity: 0.83,
        lastUpdated: now
    },
    {
        id: 'gm-eth',
        symbol: 'GMX',
        name: 'GMX',
        category: 'migrated',
        price: 36.7,
        priceChange24h: 0.024,
        volume24h: 260_000,
        marketCap: 340_000_000,
        liquidity: 0.88,
        lastUpdated: now
    },
    {
        id: 'rndr-eth',
        symbol: 'RNDR',
        name: 'Render',
        category: 'migrated',
        price: 7.12,
        priceChange24h: 0.091,
        volume24h: 430_000,
        marketCap: 2_800_000_000,
        liquidity: 0.89,
        lastUpdated: now
    },
    {
        id: 'matic-eth',
        symbol: 'MATIC',
        name: 'Polygon',
        category: 'migrated',
        price: 0.96,
        priceChange24h: -0.017,
        volume24h: 870_000,
        marketCap: 9_600_000_000,
        liquidity: 0.94,
        lastUpdated: now
    },
    {
        id: 'ldo-eth',
        symbol: 'LDO',
        name: 'Lido DAO',
        category: 'migrated',
        price: 2.14,
        priceChange24h: 0.039,
        volume24h: 330_000,
        marketCap: 1_900_000_000,
        liquidity: 0.9,
        lastUpdated: now
    },
    {
        id: 'rpl-eth',
        symbol: 'RPL',
        name: 'Rocket Pool',
        category: 'migrated',
        price: 29.6,
        priceChange24h: -0.018,
        volume24h: 120_000,
        marketCap: 600_000_000,
        liquidity: 0.88,
        lastUpdated: now
    },
    {
        id: 'bal-eth',
        symbol: 'BAL',
        name: 'Balancer',
        category: 'migrated',
        price: 4.32,
        priceChange24h: 0.027,
        volume24h: 95_000,
        marketCap: 220_000_000,
        liquidity: 0.84,
        lastUpdated: now
    },
    {
        id: 'inch-eth',
        symbol: '1INCH',
        name: '1inch',
        category: 'migrated',
        price: 0.54,
        priceChange24h: 0.041,
        volume24h: 150_000,
        marketCap: 430_000_000,
        liquidity: 0.86,
        lastUpdated: now
    },
    {
        id: 'dydx-eth',
        symbol: 'DYDX',
        name: 'dYdX',
        category: 'migrated',
        price: 3.1,
        priceChange24h: 0.052,
        volume24h: 210_000,
        marketCap: 730_000_000,
        liquidity: 0.9,
        lastUpdated: now
    },
    {
        id: 'fxs-eth',
        symbol: 'FXS',
        name: 'Frax Share',
        category: 'migrated',
        price: 4.96,
        priceChange24h: -0.026,
        volume24h: 88_000,
        marketCap: 390_000_000,
        liquidity: 0.85,
        lastUpdated: now
    },
    {
        id: 'yfi-eth',
        symbol: 'YFI',
        name: 'Yearn Finance',
        category: 'migrated',
        price: 12_400,
        priceChange24h: 0.012,
        volume24h: 32_000,
        marketCap: 450_000_000,
        liquidity: 0.82,
        lastUpdated: now
    },
    {
        id: 'comp-eth',
        symbol: 'COMP',
        name: 'Compound',
        category: 'migrated',
        price: 68.7,
        priceChange24h: 0.029,
        volume24h: 77_000,
        marketCap: 520_000_000,
        liquidity: 0.87,
        lastUpdated: now
    }
];
async function GET(req) {
    const { searchParams } = new URL(req.url);
    const categoryParam = searchParams.get('category') ?? 'new_pairs';
    const data = baseTokens.filter((t)=>t.category === categoryParam);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(data);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__3f5accc7._.js.map