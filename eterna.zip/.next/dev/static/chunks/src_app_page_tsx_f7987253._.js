(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_574f0e56._.js",
  "static/chunks/node_modules_1834cc4d._.js"
],
    source: "dynamic"
});
